import React from "react";
// import OrdersDashboard from "./components/OrdersDashboard";
import DashBoard from "./components/orderDashboard/DashBoard";

function App() {
  return (
    <div>
      <DashBoard/>
    </div>
  );
}

export default App;
